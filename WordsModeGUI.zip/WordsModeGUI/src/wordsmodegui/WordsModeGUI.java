/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package wordsmodegui;
import javax.swing.*;

public class WordsModeGUI {
    public static void main(String[] args) {
    PickRange pick = new PickRange();
    pick.setSize(720,400);
    pick.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    pick.setVisible(true);
        
    }
}
